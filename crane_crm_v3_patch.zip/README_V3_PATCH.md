# Crane CRM v3 patch

This patch adds:

1. Clickable company names in the Streamlit CRM table.
2. AI-extracted mobile crane capacity range/details.
3. AI-extracted responsible sales/purchase contacts, using website evidence and legacy workbook contacts.
4. Optional crane/equipment color hints from scraped website images, plus LLM color-scheme extraction.

Replace these paths in your project:

```text
src/schemas.py
src/search.py
src/scraper.py
src/llm_groq.py
src/enrich_pipeline.py
app/streamlit_app.py
requirements.txt
```

Run a small test:

```bash
pip install -r requirements.txt
python -m src.enrich_pipeline \
  --input "data/input/!E-MAIL PEDIDOS MUNDO.xlsx" \
  --output data/output/enriched_companies_v3_test.csv \
  --limit 10 \
  --no-resume
```

Then open the dashboard:

```bash
streamlit run app/streamlit_app.py
```

Notes:

- `company_website_url` is used to make company names clickable in the dashboard.
- `responsible_sales_contacts` preserves legacy workbook contacts when the website does not expose a clearer sales/purchase contact.
- `crane_color_scheme` is best effort. It uses text evidence plus optional image color hints; if the source images are generic, confidence should stay low.
- `Pillow` is used for optional image color extraction. The pipeline still runs without color extraction if image analysis fails for a website.
